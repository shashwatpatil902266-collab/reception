# ⚡ QUICK START — Dad's WhatsApp Gold Tracker

**Goal:** Get a daily WhatsApp message to Dad with gold analysis, working in under 30 minutes.

---

## 🎯 Three Paths — Pick One

### 🥇 PATH A: Wassenger (Best, ₹500/mo extra)
**Time:** 15 min | **Cost:** ₹2,200/mo total | **Reliability:** ⭐⭐⭐⭐⭐

```
Claude Routine → Wassenger MCP → Dad's WhatsApp
```

### 🥈 PATH B: Gmail → IFTTT → WhatsApp (FREE)
**Time:** 25 min | **Cost:** ₹1,700/mo (only Claude Pro) | **Reliability:** ⭐⭐⭐⭐

```
Claude Routine → Your Gmail → IFTTT → Dad's WhatsApp
```

### 🥉 PATH C: SMS Fallback (If WhatsApp too hard)
**Time:** 10 min | **Cost:** ₹1,709/mo | **Reliability:** ⭐⭐⭐⭐⭐

```
Claude Routine → Twilio SMS → Dad's Phone
```

---

## 🚀 PATH A: WASSENGER SETUP (Recommended)

### Step 1: Prerequisites (5 min)
- [ ] Active Claude Pro subscription (₹1,700/mo)
- [ ] Claude Code on web enabled
- [ ] GitHub account
- [ ] Dad's WhatsApp number handy

### Step 2: Get Wassenger (5 min)
1. Go to **wassenger.com**
2. Sign up for **Starter plan** (₹500/mo)
3. Connect your WhatsApp by scanning QR code
4. Copy your **API key** from dashboard
5. Save it somewhere safe

### Step 3: Add WhatsApp to Claude Connectors (2 min)
1. Open Claude settings → Connectors
2. Click "Add MCP Server"
3. Enter:
   ```json
   {
     "type": "http",
     "url": "https://api.wassenger.com/mcp?key=YOUR_WASSENGER_API_KEY"
   }
   ```
4. Name it: **"WhatsApp (Wassenger)"**
5. Save and verify it shows "Connected"

### Step 4: Upload Files to GitHub (5 min)
1. Create private repo: `gold-tracker-routine`
2. Install Claude GitHub App on it
3. Upload all 11 Gold Tracker files (README.md, project_instructions.md, etc.)

### Step 5: Create the Routine (5 min)
1. Go to **claude.ai/code/routines**
2. Click "Create Routine"
3. **Name:** `Dad's Gold Report`
4. **Repository:** Select `gold-tracker-routine`
5. **Prompt:** Open `DAD_WHATSAPP_PROMPT.md` and paste entire content
6. **IMPORTANT:** Find and replace in the prompt:
   - `DAD_PHONE` → `+91XXXXXXXXXX` (your dad's number)
   - `DAD_NAME` → `Papa` (or whatever you call him)
   - `YOUR_NAME` → Your name
   - `YOUR_EMAIL` → Your email
7. **Trigger:** Daily at 9:00 AM IST
8. **Connectors:** Select WhatsApp (Wassenger) + Web Search + GitHub + Google Drive
9. Click **Create**

### Step 6: Test It (3 min)
1. First, change phone to **YOUR OWN** WhatsApp number for test
2. Click **"Run Now"**
3. Wait 3-5 min
4. Check your WhatsApp for the message
5. Review formatting, adjust prompt if needed
6. Once perfect, change back to Dad's number
7. Click "Run Now" one more time to verify

### ✅ Done! Dad gets gold analysis tomorrow at 9 AM.

---

## 🆓 PATH B: GMAIL → IFTTT SETUP (Free Method)

### Step 1: Prerequisites (5 min)
Same as Path A, but no Wassenger needed.

### Step 2: Set Up Gmail Connector (2 min)
1. Claude settings → Connectors → Gmail
2. Authorize your Google account
3. Grant send permission

### Step 3: Set Up IFTTT (10 min)
1. Go to **ifttt.com** → Sign up (free)
2. Click **Create** (top right)
3. **IF (Trigger):**
   - Service: **Gmail**
   - Event: "New email in inbox from search"
   - Search: `subject:"[GOLD-TRACKER-DAD]"`
4. **THEN (Action):**
   - Option A: If IFTTT has WhatsApp in your region:
     - Service: **WhatsApp**
     - Send message to: Dad's number
     - Message: `{{BodyPlain}}`
   - Option B: Use CallMeBot (free WhatsApp API):
     - Service: **Webhooks**
     - URL: `https://api.callmebot.com/whatsapp.php?phone=DAD_NUMBER&text={{BodyPlain}}&apikey=YOUR_KEY`
     - First register at callmebot.com to get API key
5. Name applet: **"Gold Tracker to Dad's WhatsApp"**
6. Click **Finish**

### Step 4: Upload Files to GitHub (5 min)
Same as Path A Step 4.

### Step 5: Create Routine (3 min)
Same as Path A Step 5, but:
- **Connectors:** Gmail + Web Search + GitHub + Google Drive (NO Wassenger)
- In the prompt, keep the Gmail delivery section active
- Make sure email subject starts with `[GOLD-TRACKER-DAD]`

### Step 6: Test Flow (5 min)
1. Run the routine manually
2. Check your Gmail for the report (arrives first)
3. IFTTT picks it up within 15 min
4. Dad receives WhatsApp message
5. **Note:** IFTTT has ~5-15 min delay — not instant

### ✅ Done! Free WhatsApp delivery for Dad.

---

## 📱 PATH C: TWILIO SMS (Simplest)

If WhatsApp setup is too complex OR Dad prefers SMS:

### Step 1: Get Twilio (5 min)
1. Go to **twilio.com** → Sign up (free trial)
2. Verify your phone
3. Get a Twilio phone number (free with trial)
4. Copy: Account SID, Auth Token, Twilio phone number

### Step 2: Add Twilio MCP to Claude (2 min)
Several Twilio MCP servers exist:
- Search "Twilio MCP" in Claude Connectors directory
- Add with your Twilio credentials

### Step 3: Modify Routine Prompt
Replace the "DELIVER THE MESSAGE" section in DAD_WHATSAPP_PROMPT.md with:
```
Use Twilio SMS connector to send to DAD_PHONE:
- Message: [formatted report, but trimmed to 1600 chars for SMS]
- From: [Your Twilio number]
```

### Step 4: Create Routine
Same as Path A, but use Twilio instead of Wassenger.

### ✅ Done! Dad gets text messages daily.

---

## 📲 TESTING CHECKLIST

Before going live with Dad's real number:

### Message Quality
- [ ] All placeholders replaced (no "DAD_NAME" literally shown)
- [ ] Dad's name spelled correctly
- [ ] Your name in sign-off
- [ ] Date is today's date
- [ ] Prices are current (not from training data)
- [ ] Language is appropriate (English/Hindi/Hinglish as you chose)

### Formatting
- [ ] Emojis render on WhatsApp
- [ ] Line breaks preserve on mobile
- [ ] No cut-off at 1024 chars (WhatsApp legacy limit)
- [ ] Under 2000 chars total
- [ ] No broken markdown (no **bold** — WhatsApp doesn't render)

### Content
- [ ] Recommendation is ONE clear action
- [ ] Stop-loss and target included
- [ ] Top 3 reasons listed
- [ ] Risk warnings present
- [ ] Disclaimer at bottom

### Delivery
- [ ] Message arrives within 5 min of routine run
- [ ] Sender shows as your name/number (not "WhatsApp Business")
- [ ] Timestamp is correct IST

---

## 💬 HOW TO INTRODUCE THIS TO DAD

### Option 1: Surprise Him 🎁
Just start sending. Let him discover it!

### Option 2: Tell Him First 👨‍👧
Send this message a day before activation:
```
Hi Dad!
Starting tomorrow, I'll send you daily
gold price analysis every morning.

It uses AI (like the tech news you 
watched) to check prices, news, and
expert views. Then gives you a 
simple BUY/HOLD/SELL tip.

Just read it with your morning chai!

Let me know if format needs changes.
Love ❤️
- [Your Name]
```

### Option 3: Set Expectations 📋
```
Hi Dad!
New routine: Gold tracker!

Every morning at 9 AM you'll get:
• Current gold price
• Buy/hold/sell tip
• Reasons why
• Stop-loss & target

It's automated but the reasoning
is good. Use it as one input for 
your decisions.

Try it for a week and tell me what
works/doesn't.

Love, [Your Name]
```

---

## 🎁 FIRST-WEEK TUNING GUIDE

### Day 1-3: Monitor Closely
- [ ] Is Dad reading messages? (Check WhatsApp "read" status)
- [ ] Is format readable on his phone?
- [ ] Is the language right for him?

### Day 4: Ask for Feedback
Text Dad:
```
Hi Dad, how's the gold report?
Too much info? Too little?
Want it in Hindi? At different time?
Let me know!
```

### Day 7: Make Adjustments
Based on Dad's feedback, update the prompt:
- Shorter? → Remove historical parallel section
- Simpler? → Remove percentage probabilities
- Hindi? → Add language instruction
- Different time? → Update schedule
- More detail? → Add portfolio tracking

---

## 📊 WHAT IF DAD LOVES IT?

### Expand the Service

**Week 2:** Add weekly summary every Sunday
**Week 3:** Add alerts on big moves (>2% swings)
**Week 4:** Include silver tracking too
**Month 2:** Add stock market overview
**Month 3:** Family group chat version

### Show It to Friends
When Dad brags to his friends about "my son/daughter built me an AI gold advisor":
- They'll want one too!
- You become the tech guru of the family
- Potential: Build it as a service for others

---

## ⚠️ IMPORTANT WARNINGS

### Don't:
- ❌ Send messages too early (before 7 AM) — might wake Dad up
- ❌ Send too many messages per day (1 is enough for most dads)
- ❌ Forget the "not financial advice" disclaimer
- ❌ Make trades on Dad's behalf — only provide info
- ❌ Share his phone number or data with services

### Do:
- ✅ Test thoroughly before real delivery
- ✅ Monitor first week carefully
- ✅ Keep the tone warm and personal
- ✅ Update Dad if routine fails (don't just go silent)
- ✅ Adjust based on his feedback

---

## 🎯 TROUBLESHOOTING

### "Routine ran but Dad didn't get message"
**Check:**
1. Wassenger dashboard → Message Logs → Delivery status
2. Dad hasn't blocked/archived your WhatsApp number
3. Phone number format is correct: `+919876543210`

### "Message format is broken"
**Fix:**
1. WhatsApp doesn't support:
   - Markdown tables → Use lists
   - Complex bolding → Use emojis for emphasis
   - Code blocks → Use plain text
2. Keep messages under 2000 chars
3. Use `\n\n` for paragraph breaks

### "IFTTT didn't forward the email"
**Check:**
1. Gmail subject exactly starts with `[GOLD-TRACKER-DAD]`
2. IFTTT applet is active (not paused)
3. Gmail connector permission in IFTTT
4. Check IFTTT activity log

### "Dad says it's too technical"
**Fix the prompt:**
1. Remove percentages (just say "likely up")
2. Remove jargon (RSI, MACD, etc.)
3. Focus on: price + one clear action + simple reason
4. Add Hindi explanations for key terms

---

## 💰 MONTHLY COST SUMMARY

| Component | Path A (Wassenger) | Path B (Free) | Path C (SMS) |
|-----------|-------------------|---------------|--------------|
| Claude Pro | ₹1,700 | ₹1,700 | ₹1,700 |
| WhatsApp service | ₹500 | ₹0 | - |
| SMS service | - | - | ₹9 |
| **TOTAL** | **₹2,200** | **₹1,700** | **₹1,709** |
| **Per message** | **₹73** | **₹57** | **₹57** |

**Compared to:**
- Motilal Oswal gold research: ₹3,000/month (not personalized)
- Professional advisor: ₹5,000+/month
- Your Gold Tracker to Dad: **₹57-73/day of personalized AI analysis** 🏆

---

## ✅ YOUR 30-MINUTE CHECKLIST

- [ ] Subscribe to Claude Pro (if not)
- [ ] Create GitHub repo & upload 11 files
- [ ] Choose delivery path (A, B, or C)
- [ ] Set up chosen service (Wassenger/IFTTT/Twilio)
- [ ] Copy DAD_WHATSAPP_PROMPT.md
- [ ] Replace placeholders with real info
- [ ] Create routine at claude.ai/code/routines
- [ ] Test with your own phone first
- [ ] Switch to Dad's number
- [ ] Send Dad a preview message
- [ ] Enable daily schedule
- [ ] Celebrate! 🎉

---

**You're about to become Dad's favorite child.** 🏆❤️
